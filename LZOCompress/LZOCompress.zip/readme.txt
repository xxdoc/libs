
sample using miniLZO compression library in vb6

vs2008 was used to compile the dll

'for decompression, it would probably be better to pass in the original size to get an idea
'of the buffer size to allocate. in practice I would include a header in comporessed data
'that included original size and original md5

any updates will be here:

https://github.com/dzzie/libs/tree/master/LZOCompress
