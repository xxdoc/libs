/*	pre compiled header */
#ifndef __TAR32_STDAFX_H
#define __TAR32_STDAFX_H

#include <time.h>
#include <windows.h>
#include <sys/types.h>	// stat
#include <sys/stat.h>	// S_IWRITE
#include <wtypes.h>

#include <string>
#include <list>

#endif
