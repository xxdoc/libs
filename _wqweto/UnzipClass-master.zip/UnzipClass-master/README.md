## VB6 Unzip Class
This is a pure VB6 class for extracting zip archives with no dependency on other libraries or modules.

Based on [_+Compression Methods+_ V 1.04](http://www.planetsourcecode.com/vb/scripts/ShowCode.asp?txtCodeId=37867&lngWId=1) by Marco v/d Berg and optimizations by John Korejwa.

Original code is completely refactored to be wrapped in a self-containing class module.