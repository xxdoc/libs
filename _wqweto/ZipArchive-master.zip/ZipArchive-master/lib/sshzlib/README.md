### PuTTY license
`sshzlib.c` is part of PuTTY project and is copyright 1997-2017 Simon Tatham.

Please read included LICENSE file for full details.