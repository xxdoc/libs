
vs2008 C dll that includes math operations for unsigned int, 
longs and 64 bit number support for vb6

if the c dll is stripped you can download it from the github repo

https://github.com/dzzie/libs/tree/master/vb6_utypes

