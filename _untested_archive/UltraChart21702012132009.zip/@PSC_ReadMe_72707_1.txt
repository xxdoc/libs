Title: UltraChart
Description: UPDATE 2009/12/13--------------------------------
Clear method bug fixed,
-------------------------------------------------
UltraChart, the next generation of WINNER Animated Chart (as i promise before),
There are lots of improvements:
 Multi Series added, Full OwnerDraw , Animation On/Off, Print, Save, Now using Tooltip to show data informations rather than label, Customize text rotation and ...
Animated Chart is the first PSC Animation Chart, now all Bar Charts grow simoltaneously,
Hope you like this, please vote and let me know your idea about UltraChart,
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=72707&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
