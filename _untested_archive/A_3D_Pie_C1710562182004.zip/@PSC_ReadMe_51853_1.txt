Title: A 3D Pie Chart Control
Description: Design a 3D piechart for your custom app using an array of percentages. You can change the color scheme, and add mouseover , mousedown, and mouseup events for each pie piece in the chart
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=51853&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
