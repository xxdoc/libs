#pragma once

#include <objbase.h>

STDAPI DllGetClassObject(const CLSID& clsid, const IID& iid, void**ppv);