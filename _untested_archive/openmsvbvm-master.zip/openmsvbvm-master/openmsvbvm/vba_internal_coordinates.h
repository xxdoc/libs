#pragma once

#include "vba_internal.h"

//LONG convertCoordinates()
