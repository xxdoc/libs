//{{NO_DEPENDENCIES}}
// Archivo de inclusi�n generado de Microsoft Visual C++.
// Usado por Resource.rc
//
#define ID_DIALOG_INPUTBOX              5
#define IDC_BUTTON_HELP                 1001
#define IDC_EDIT1                       1002
#define IDC_INPUT                       1002
#define IDC_BUTTON_OK                   1003
#define IDC_BUTTON_CANCEL               1004
#define IDC_USER_STATIC                 1005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
