#pragma once

#include "vba_internal.h"

LCID getUserLocale();