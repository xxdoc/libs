Title: Final - vhGrid!  - 1.7  (Update July 07)
Description: v1.7 Is Up!
The uber~grid.. 
Skinnable headers/scrollbars/checkboxes, integrated treeview, 16 integrated api edit controls, virtual mode, unbound data mode, 32b alpha icon support, sizeable header height, ole drag and drop, full unicode support, column filters, subcell controls, cell tooltips, column tips, custom cursors, ownerdrawn cells..
Hundreds of functions and properties, 27 thousand lines of code..
Dig in, have fun..
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=67906&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
