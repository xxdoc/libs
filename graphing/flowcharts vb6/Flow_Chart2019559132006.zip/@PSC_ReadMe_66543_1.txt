Title: Flow Chart Designer
Description: Flow Chart designer is used to design 3d Flow charts like in SQL Server DTS Package.Where you have some nodes as tasks or connection, and line connecting task as workflow order.You may put some labels on your chart and adjust lot of properties ( OutLines,Transparency etc) to adjust the label objects.You can move various objects and zoom in or zoom out the graph.You can also save or load the graph as flat file or in database.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=66543&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
