
How to register a protocol handler
----------------------------------

1) Add a key for the protocol under HKEY_CLASSES_ROOT\PROTOCOLS\Handler. Use the protocol scheme
   as the key name:

   HKEY_CLASSES_ROOT\PROTOCOLS\Handler\rsview

2) Under that key, add a string value named CLSID:

   HKEY_CLASSES_ROOT\PROTOCOLS\Handler\rsview\CLSID = "{YOUR CLASS ID HERE}"


