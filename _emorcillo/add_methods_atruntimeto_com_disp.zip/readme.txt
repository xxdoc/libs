ATTENTION!!!

modFunctionDelegator and modResetError were taken from Matt Curland's 
"Call Function Pointers" article from the February 2000 edition of VBPJ.
