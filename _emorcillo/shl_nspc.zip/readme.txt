
Installing the namespace
------------------------

To install the namespace open the Install folder, right click
the vbproj.inf file and select Install from the menu.

