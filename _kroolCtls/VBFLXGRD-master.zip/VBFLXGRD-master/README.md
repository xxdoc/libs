# VBFLXGRD
VB FlexGrid Control (Replacement of the MSFlexGrid control)

This project is intended to replace the MSFlexGrid control for VB6.

http://www.vbforums.com/showthread.php?848839-VBFlexGrid-Control-(Replacement-of-the-MSFlexGrid-control)
