
https://www.planet-source-code.com/vb/scripts/ShowCode.asp?txtCodeId=74641&lngWId=1

CMultiBits [Updated March 12, 2017]
PURPOSE:

CMultiBits is a class, with no dependencies, that handles bit manipulation in Byte, Integer, Long, Single, Double, Currency, Dates, and Long Arrays. (These are VarTypes 2 thru 7, 17 and 8195. The Long Arrays are in place of Decimals but can be expanded way beyond Decimal size. It should be noted that the class can only handle one dimensional long arrays.)

FEATURES:

CMultiBits manipulates bits (including the sign bit) in all the above data types. It allows creating bitfields of any size from 8 bits (Byte) to 64 bits (Currency, Dates or Doubles), or up to unlimited size using a long array acting as a single bit field. (You can even do bit shifting and rotating on a long array and it will act as if it were a single bitfield.) And all of these variables (including long arrays) all use the same public interface.

Another feature is the ability to store numeric values within a bitfield, right along with boolean values, making for what might be called a 'hybrid bitfield.'

The class features the option to use typecasting for strings, Singles, 64 bit data types and long arrays. It also makes use of VB's hidden GetMem and PutMem methods. (Typecasting was adapted from a Bonnie West class - many thanks.) There are also a number of optional parameters that allow some flexibility in the class.

The class also has a complete collection of Byte/Integer/Long /Currency Combo & Extraction routines, as well has bit/hex string read & write routines.

Copious notes are included to help understand the code.

INTERFACE:

For bit manipulation: SetBitFlag/ClearBitFlag (single & multiple bits), Toggle, Shift, Rotate, ReverseBits, ReverseBytes, CountBits, Bit/Hex string creating & reading. CustomValue (property get/let) is for inserting & extracting numeric values from bit fields. IsFlagged reads one bit or multiple bits.

The combo/extract routines include: LoNibble/HiNibble/MakeByte (Extract/combine nibbles.) LoByte/HiByte/MakeWord (Extract/combine bytes.) LoWord/HiWord/MakeDWord (Extract/combine integers.) LoDWord/HiDWord/MakeQWord (Extract/combine longs.) LongFromBytes (Combine 1 to 4 bytes to form a long.) ByteFromLong (Extract any byte from a long.) ByteIntoLong (Insert a byte into any position of an existing long.) ByteFromCurr (Extract any byte from currency) ByteIntoCurr (Insert byte into any byte position of currency. IntFromCurr (Extract any integer from a currency), IntIntoCurr (Insert an integer into any int position of a currency)

UPDATES:

3/12/17: Updates include all the debug statements so that they now properly show "Module.Method: Information . . ." There were also just a couple of small refinements in a few places in the code. And many of the remarks were updated to reflect the improved capabilities in the last couple of updates. There are no changes to the public interface. So any existing code that uses this class will continue to work as-is. Any improvements, ideas or bug reports would be much appreciated. See just above "Option Explicit" for a complete listing of features and improvement history. Incidentally, the interface will also handle a long array contained within a UDT. It will treat it the same as a normally dimensioned long array. 