-------------------------------------------------
XML Parser by Jason Thorn (Fork by Alex Dragokas)
-------------------------------------------------

Here is 2 projects:

1) GUI: compile vbXml-browser\Browser\Browser.vbg

2) Simple app (debug. window sample): vbXml-simple\Project.vbp

'xml-files' folder has a sample .xml files.

Good luck :)

