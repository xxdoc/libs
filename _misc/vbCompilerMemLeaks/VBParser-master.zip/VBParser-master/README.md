# VBParser
[PoC] Visual Basic 5/6 compiler memory leak inside created executable files

This is related to:
https://sysenter-eip.github.io/VBParser (screenshots and examples)
