Title: LynxGrid v1.89 (owner-drawn editable grid)
Description: Added FormatCells method for fast bulk formatting and per cell Fontname properties.
Owner-drawn Grid. Features include CheckBoxes, Images, Multi-select, dynamic Column Sorting/Resizing, Cell Formatting (BackColor, ForeColor, FontBold etc), datatype aware sorts, custom sorts, Independent Row Heights, Word Wrap, Column Drag, Cell Images and auto-scrolling (when mouse dragged out of control). A Control Binding System allows external controls to be used for editing Cells (ComboBox, DateTimePicker etc). Supports native XP Themes &amp; emulation of XP/Office XP Themes. Feedback welcome (votes appreciated!) Credits in source for PSC authors who have helped make this possible.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=65559&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
