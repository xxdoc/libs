How to compile?
~~~~~~~~~~~~~~~

First, register this typelib

	0. Tlb\SubclassingSink.tlb

Compile in this particular order

	1. OutlookBar\OutlookBar.vbp
	2. PropPages\PropPages.vbp
	3. Samples\Project2

If you need only the color picker then you can use

	4. ColorPickerAlone\Project1

Last project will ask to modify cMemDC to private - just ignore it (and don't save)


What's this?
~~~~~~~~~~~~

This is fairly complete outlookbar emulation control. OLEDrag'n'Drop is complete (both
for items and groups). LabelEdit is complete (both for items and groups).

Enojoy,
</wqw>
Vlad Vissoultchev

5 Nov, 2002